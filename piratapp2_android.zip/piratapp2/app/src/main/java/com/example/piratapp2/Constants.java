package com.example.piratapp2;

public class Constants {
    public static final String BASE_URL = "http://192.168.1.11/piratapp/app/services/";
}
