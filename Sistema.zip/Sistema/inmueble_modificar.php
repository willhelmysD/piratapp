<?php  
	include 'plantilla.html'; 
  	require_once 'includes/class_inmuble.php';  
  	$inmueble_class =  new Inmueble();
?>
<?php startblock('article') ?>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="row">
      <div class="col-12 col-xl-8 mb-4 mb-xl-0">
        <h3 class="font-weight-bold">Inmueble</h3>
        <h6 class="font-weight-normal mb-0">Modificar informacion del inmuble</h6>
      </div>
    </div>
  </div>
</div>

<?php endblock() ?>