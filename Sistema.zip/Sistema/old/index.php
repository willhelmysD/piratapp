<?php 
	include 'plantilla.html'; 
?>

<?php startblock('title') ?>
   Home
<?php endblock() ?>

<?php 
startblock('article');   	
   	$lista =  $consultas_usuario->listar_usuarios();
?>
<div class="row">
	<div class="col-lg-3 col-md-6 col-sm-6">
		<div class="card card-stats">
			<div class="card-header card-header-warning card-header-icon">
				<div class="card-icon">
					<i class="material-icons">weekend</i>
				</div>
				<p class="card-category">Usuarios</p>
				<h3 class="card-title"><?php echo count($lista);?></h3>
			</div>
			<div class="card-footer">
				<div class="stats">
					<i class="material-icons text-danger">warning</i>
					<a href="#pablo">Get More Space...</a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- comentario -->   	
<?php
//nUserID	cNombre	cApellido	cCc	lEstado	dCreacion	nTipoID	
endblock(); 
?>



