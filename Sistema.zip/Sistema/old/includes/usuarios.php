<?php 
require ('conn.php');
class usuarios extends conectarDB{		

	public function usuarios(){				
		parent::__construct();
	}

	public function listar_usuarios(){
		$sql="select * from usarios";				
		$sentencia = $this->conn_db->prepare($sql);		
		$sentencia->execute();			
		$resultados= $sentencia->fetchAll(PDO::FETCH_ASSOC);
		$sentencia->closeCursor();
		return $resultados;
		$this->conexion_bd=null;			
	}

}	

?>