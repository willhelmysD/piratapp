<?php		
	define('DB_HOST', 'mysql:host=localhost; dbname=dbpirataapp');
	define('DB_USER', 'root');
	define('DB_PASS', '');	
?>