<?php    
require ('conn.php');
class users extends conectarDB{		

	public function users(){				
		parent::__construct();
	}

	/* listar los usuarios */
	public function listar_usuarios(){
		$sql="select * from tusers";				
		$sentencia=$this->conn_db->prepare($sql);						
		$sentencia->execute();			
		$resultados = $sentencia->fetchAll(PDO::FETCH_ASSOC);			
		$sentencia->closeCursor();
		return $resultados;
		$this->conexion_bd=null;			
	}	

	public function seleccionar_user($id){
		$sql="select * from tusers where nUserID = :id";
		$sentencia = $this->conn_db->prepare($sql);			
		$sentencia->bindParam(':id', $id);		
		$sentencia->execute();
		$resultados = $sentencia->fetch(PDO::FETCH_ASSOC);
		$sentencia->closeCursor();
		return $resultados;
		$this->conexion_bd = null;
	}

	public function seleccionar_user_condicion($condicion){
		$sql="select * from tusers where estado = :dato";
		$sentencia=$this->conn_db->prepare($sql);	
		$sentencia->bindParam(':dato', $condicion);				
		$sentencia->execute();
		$resultados=$sentencia->fetchAll(PDO::FETCH_ASSOC);
		$sentencia->closeCursor();
		return $resultados;
		$this->conexion_bd=null;
	}

	/* funcion que permite registrar un nuevo usuario */
	public function nuevo_usuario($nick,$password){
		$query_save="Insert into tusers(nick,password) value(:nick,:password)";
		$guardar=$this->conn_db->prepare($query_save);		
		$guardar->bindParam(':nick', $nick);    			 	
		$guardar->bindParam(':password', $password);    			 			
		$guardar->execute();
		$result = $this->conn_db->lastInsertId();
		$guardar->closeCursor();
		return $result;
		$this->conexion_bd=null;			
	}

	public function modificar_usuario($id, $nombre, $apellido, $cc){
		$query_modify="update tusers set cNombre = :nombre, cApellido = :apellido, cCc = :cc where nUserID = :id";
		$modificar=$this->conn_db->prepare($query_modify);	
		$modificar->bindParam(':nombre', $nombre);		
		$modificar->bindParam(':apellido', $apellido);		
		$modificar->bindParam(':cc', $cc);		
		$modificar->bindParam(':id', $id);		
		$modificar->execute();					
		$result =1;
		$modificar->closeCursor();
		return $result;
		$this->conexion_bd=null;				
	}	


}
?>
