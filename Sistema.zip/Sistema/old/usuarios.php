<?php  include 'plantilla.html'; ?>

<?php startblock('title') ?>
   Usuarios
<?php endblock() ?>

<?php 
	startblock('article');   	
	

   	$lista =  $consultas_usuario->listar_usuarios();

?>

<div class="row">
	<div class="col-md-10">
		<div class="card">
			<div class="card-header card-header-rose card-header-icon">
				<div class="card-icon">
					<i class="material-icons">assignment</i>
				</div>
				<h4 class="card-title">Usuarios Activos</h4>
			</div>

			<div class="card-body">
				<div class="table-responsive">
					<table class="table">
						<thead>
							<?php
								$cont = 0;
								foreach($lista as $key) {
									$cont++;
							?>
							<tr>
								<td class="text-center"><?php echo $cont?></td>
								<td><?php echo $key['cNombre']?></td>
								<td><?php echo $key['cCc']?></td>
								<td><?php echo $key['cApellido']?></td>								
								<a type="button" class="btn btn-danger" href="modificar_user.php?ID=<?php echo $key['nUserID']?>">
									<i class="material-icons">ir modificar</i>
								<a/>
								</td>
							</tr>
							<?php }?>
						</tbody>
					</table>
</div>
</div>
</div>
</div>	
</div>


<?php
	endblock(); 
?>
