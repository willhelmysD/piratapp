<?php
    require_once '../includes/class_users.php';
    $consulta =  new users();
    if(isset($_POST['id']) || ){

    }else{

        echo "error";
    }
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $cc = $_POST['cc'];

    $consulta->modificar_usuario($id,$nombre,$apellido,$cc);
    
?>    