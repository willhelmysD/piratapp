<?php  include 'plantilla.html'; ?>

<?php startblock('title') ?>
   Modificar Usuarios
<?php endblock() ?>

<?php 
	startblock('article');   	
		echo $user = $_GET['ID'];
		$datos = $consultas_usuario->seleccionar_user($user);
		//echo $update = $consultas_usuario->modificar_usuario(2, 'will', 'duran', 1000);
?>
<form id="" method="post" action="action/modificar_user.php">
	<input type="hidden" value="" id="" name="id">
	<label>Nombre</label>
	<input type="text" value="<?php echo $datos['cNombre']?>" id="" name="nombre">

	<label>Apellido</label>
	<input type="text" value="<?php echo $datos['cApellido']?>" id="" name="apellido">

	<label>Cedula</label>
	<input type="text" value="<?php echo $datos['cCc']?>" name="cc">

</form>

<?php
	endblock(); 
?>
