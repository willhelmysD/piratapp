
$listado_psicologos = $consultar->listar('psicologo');
echo count($listado_psicologos);
foreach($listado_psicologos as $fila){
	echo $fila['nombre'].' '.$fila['telefono'];
}
*/
/*
$usuarios = $consultar->listar('usuarios');
$datos = $_POST['DAtos']
$save = $consultar->guardar($tabla, $datos);
*/
?>

<section style="text-align: center;">
    <h2>Sección Destacada</h2>
    <p>Contenido de la sección destacada.</p>
</section>
<form>
	<input type="" name="datos[nombres]" value="<?php echo datos['nombres']?>">
	<input type="" name="datos[apellidos]">	
</form>
<?php foreach ($variable as $key)?>
	echo $key['nombre'].' '.$key['apellido'];
	?>
<?php endforeach ?>?>
<div class="row">
	
</div>


