<?php  
	include 'plantilla.html'; 
  	require_once 'includes/class_inmuble.php';  
  	$inmueble_class =  new Inmueble();
  	$lista = $inmueble_class->listar_inmuebles();
?>
<?php startblock('article') ?>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="row">
      <div class="col-12 col-xl-8 mb-4 mb-xl-0">
        <h3 class="font-weight-bold">Inmueble</h3>
        <h6 class="font-weight-normal mb-0">total de inmuebles registrados  <span class="text-primary"><?php echo count($lista)?></span></h6>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <p class="card-title mb-0">Inmuebles Registrados</p>
        <div class="table-responsive">
          <table class="table table-striped table-borderless">
            <thead>
              <tr>
                <th>#</th>
                <th>Inmueble</th>
                <th>Piso</th>
                <th>Tipo</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                  $cont = 0;
                  foreach($lista as $key){
                  $cont++;
                ?>
              <tr>
                <td><?php echo $cont?></td>
                <td class="font-weight-bold"><?php echo $$key['numero']?></td>
                <td><?php echo $key['piso']?></td>
                <td class="font-weight-medium">
                  <div class="badge badge-success"><?php echo $$key['tipo']?></div>
                </td>
              </tr>
            <?php  } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endblock() ?>