<?php  
	include 'plantilla.html'; 
  	require_once 'includes/class_inmuble.php';  
  	$inmueble_class =  new Inmueble();
?>
<?php startblock('article') ?>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="row">
      <div class="col-12 col-xl-8 mb-4 mb-xl-0">
        <h3 class="font-weight-bold">Inmueble</h3>
        <h6 class="font-weight-normal mb-0">Agregar un nuevo inmuble</h6>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6 grid-margin stretch-card">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Nuevo Inmueble</h4>
      <p class="card-description">Formulario para agregar un nuevo inmueble en la base de datos</p>
      <form class="forms-sample" action="action/nuevo_inmueble.php" method="post">
        <div class="form-group">
          <label for="exampleInputUsername1">Numero</label>
          <input type="text" class="form-control" id="numero" name="numero" placeholder="numero">
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Piso</label>
          <input type="text" class="form-control" id="piso" name="piso" placeholder="piso">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Tipo</label>
          <select class="form-select" name="tipo">
            <option value="Aparta Estudio">Aparta Estudio</option>
            <option value="Apartamento">Apartamento</option>
            <option value="Penthouse">Penthouse</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary me-2">Enviar</button>
      </form>
    </div>
  </div>
</div>
</div>
<?php endblock() ?>