<?php    
require ('conn.php');
class Inmueble extends conectarDB{		

	public function Inmueble(){				
		parent::__construct();
	}

	public function listar_inmuebles(){
		$sql="select * from inmueble";				
		$sentencia=$this->conn_db->prepare($sql);						
		$sentencia->execute();			
		$resultados = $sentencia->fetchAll(PDO::FETCH_ASSOC);			
		$sentencia->closeCursor();
		return $resultados;
		$this->conexion_bd=null;			
	}	

	public function detallar_inmueble($id){
		$sql="select * from inmueble where inmubeleID = :id";
		$sentencia = $this->conn_db->prepare($sql);			
		$sentencia->bindParam(':id', $id);		
		$sentencia->execute();
		$resultados = $sentencia->fetch(PDO::FETCH_ASSOC);
		$sentencia->closeCursor();
		return $resultados;
		$this->conexion_bd = null;
	}

	public function agregar_inmueble($numero,$piso,$tipo){
		$query_save="Insert into inmueble(numero,piso,tipo) value(:numero,:piso,:tipo)";
		$guardar=$this->conn_db->prepare($query_save);		
		$guardar->bindParam(':numero', $numero);    			 	
		$guardar->bindParam(':piso', $piso);    			 			
		$guardar->bindParam(':tipo', $tipo);    			 			
		$guardar->execute();
		$result = $this->conn_db->lastInsertId();
		$guardar->closeCursor();
		return $result;
		$this->conexion_bd=null;			
	}

	public function modificar_inmuble($id,$numero,$piso,$tipo){
		$query_modify="update inmueble set numero = :numero, pisp = :piso, tipo = :tipo where inmuebleID = :id";
		$modificar=$this->conn_db->prepare($query_modify);	
		$modificar->bindParam(':numero', $numero);		
		$modificar->bindParam(':piso', $piso);		
		$modificar->bindParam(':tipo', $tipo);		
		$modificar->bindParam(':id', $id);		
		$modificar->execute();					
		$result =1;
		$modificar->closeCursor();
		return $result;
		$this->conexion_bd=null;				
	}	



}