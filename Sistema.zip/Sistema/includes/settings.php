<?php		
	define('DB_HOST', 'mysql:host=localhost; dbname=DBpirataApp; port=3306');
	define('DB_USER', 'root');
	define('DB_PASS', '');	
?>