<form action="test_post.php" method="post" >
    <label>nombre</label>
    <input name="nombre" id="">
    <button type="button">Enviar</button>
</form>